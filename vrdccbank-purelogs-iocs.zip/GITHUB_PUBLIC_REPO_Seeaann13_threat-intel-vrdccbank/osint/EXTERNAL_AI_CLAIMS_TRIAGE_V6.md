# External AI / Google Search AI Claims Triage V6

產出時間：2026-06-10 Asia/Taipei

來源：使用者貼上的 Google Search AI 摘要，以及本工作區已查證的公開來源。

安全邊界：此檔案只做情資比對與可信度分級；未下載 payload、未執行樣本、未連線真 C2。

---

## 1. 可信 / 已被本案資料或公開來源支持的說法

### 1.1 `vrdccbank.com/kidda.exe` 的 Suricata SID `84721509`

狀態：**已確認**

EveBox rule page 顯示：

```text
SID: 84721509
Created: June 4, 2026
Classification: trojan-activity
Rule condition:
- HTTP method GET
- http.uri content /kidda.exe, endswith, nocase
- http.host content vrdccbank.com
Reference: urlhaus.abuse.ch/url/3858409/
```

來源：

```text
https://rules.evebox.org/pub/abuse.ch/urlhaus/84721509
```

本案對應：

```text
URLhaus ID: 3858409
URL: https://vrdccbank.com/kidda.exe
Payload SHA256: c96a683aad76996c568dbc1632d8bbc6f86324231ece63de5b067c96a2167f3c
Local sample: phishing-hunter/vrdccbank_kidda.exe
```

---

### 1.2 `vrdccbank.com/freda01.exe` 與 `kidda.exe` 為 PureLogsStealer malware delivery

狀態：**已確認**

URLhaus public pages 顯示：

```text
freda01.exe
URLhaus ID: 3859115
Payload SHA256: 552d93ad7c138a43436b6b25d8fab1fae07df05db54e1dfead674add33cfe81c
Signature: PureLogsStealer
Tags: er, exe, PureLogsStea, PureLogsStealer

kidda.exe
URLhaus ID: 3858409
Payload SHA256: c96a683aad76996c568dbc1632d8bbc6f86324231ece63de5b067c96a2167f3c
Signature: PureLogsStealer
Tags: exe, PureLogsStealer
```

來源：

```text
https://urlhaus.abuse.ch/url/3859115/
https://urlhaus.abuse.ch/url/3858409/
```

補強：Hybrid Analysis public pages 對兩個 hash 皆給 malicious / AV 71%。

---

### 1.3 PureLogs 是 infostealer，並有多階段/釣魚/PowerShell/loader 情境

狀態：**大方向已支持，但不可把所有技術細節直接套到本案每個樣本**

Malpedia 對 `win.purelogs` 的定義：

```text
PureLogs / PureLog Stealer is an infostealer malware from the Pure family that aims to steal sensitive information from infected devices.
```

來源：

```text
https://malpedia.caad.fkie.fraunhofer.de/details/win.purelogs
```

Fortinet 2026-05-26 報告描述一個 PureLogs 變種 campaign：

```text
phishing email -> obfuscated JavaScript -> dropped PowerShell -> process hollowing -> downloader module -> PureLogs plugin/module
```

來源：

```text
https://www.fortinet.com/blog/threat-research/phishing-campaign-deploys-javascript-driven-purelogs-variant-to-steal-sensitive-data
```

Trend Micro 2026-03-19 報告描述：

```text
copyright lures / fileless execution / Python loader / dual .NET loaders / AMSI bypass / registry persistence / screenshot capture / victim fingerprinting / crypto wallets / browser credentials
```

來源：

```text
https://www.trendmicro.com/pt_br/research/26/c/copyright-lures-mask-a-multistage-purelog-stealer-attack.html
```

本案結論：

- `vrdccbank.com` payloads 被 URLhaus 標為 `PureLogsStealer`，可引用 PureLogs family-level capability。
- 但 Fortinet/Trend 的每個細節（例如特定 lure、特定 C2、特定 loader）不能自動推論到本案樣本，除非有本案動態證據或 hash match。

---

### 1.4 Joe Sandbox 報告支持 PureLogs JavaScript delivery chain / WScript -> PowerShell 行為

狀態：**支持 family/campaign pattern；與本案 vrdccbank 是否同一 infection chain 仍需關聯證據**

Joe Sandbox `1923511`：

```text
Sample: Kindly Requesting Your Quotation ... _pdf.js
Score: 96
Signatures include:
- JScript obfuscated calls
- Encrypted powershell cmdline option
- WScript/CScript dropper
- browser information stealing
- mail credential stealing
- language/country registry keys
- anti-VM / sandbox checks
- WScript queries suspicious COM object
Process tree: wscript.exe -> conhost.exe -> powershell.exe -EncodedCommand -> chrome.exe instances
```

來源：

```text
https://www.joesandbox.com/analysis/1923511/0/html
```

Joe Sandbox `1924897`：

```text
Sample: Order Confirmation Request ... _pdf.js
Detection: PureLogs Stealer
Score: 100
Signatures include:
- Yara PureLogs Stealer
- MSIL Injector
- Credential Stealer
- encrypted PowerShell cmdline
- WScript/CScript dropper
- browser / mail credential theft
- country/language registry checks
- anti-VM and long sleeps
Process tree: wscript.exe -> conhost.exe -> powershell.exe -EncodedCommand -> chrome.exe instances
```

來源：

```text
https://www.joesandbox.com/analysis/1924897/0/html
```

本案結論：

- 可用於 threat hunting guidance：`wscript.exe/cscript.exe -> powershell.exe -EncodedCommand`、環境變數/加密命令、browser credential theft、anti-VM。
- 但除非 Joe report 的 dropped URL/hash 直接包含 `vrdccbank.com` 或本案 SHA256，否則只能作「PureLogs delivery pattern」，不能當本案直接證據。

---

### 1.5 `turbohost30.ru` 有 TDS / landing / click endpoint 形狀

狀態：**部分支持**

本案 OTX geek sweep 補到：

```text
https://turbohost30.ru/landers/convert_hk/  HTTP 200
https://turbohost30.ru/click.php            HTTP 400
```

這支持：

```text
TDS / landing / click redirect lead
```

但「botnet、惡意靜態資源、email harvesting、bulletproof / fast-flux」等說法目前尚未在本案資料中直接證實，需保守標註為外部 AI 推論或待查。

---

## 2. 部分正確但需要修正的說法

### 2.1 `vrdccbank.com` URL status 是 Online？

狀態：**時間敏感，需修正**

使用者貼的 AI 摘要說「目前活躍中 / Online」。

本輪 URLhaus public pages 顯示：

```text
freda01.exe: Offline, down since 2026-06-10 06:03:06 UTC
kidda.exe: Offline, down since 2026-06-10 06:08:13 UTC
```

但 OTX 又在 2026-06-09 / 2026-06-10 顯示其他 vrdccbank EXE path HTTP 200：

```text
4325.exe
000111333.exe
Freda4.exe
Doppee7.exe
favour4.exe
Favour1.exe
2222.exe
```

修正結論：

```text
/kidda.exe 與 /freda01.exe 在 URLhaus 最新 public 狀態為 offline；
但 vrdccbank.com 可能仍在輪替其他 EXE path 或曾於 2026-06-10 提供其他 EXE。
```

---

### 2.2 `vrdccbank.com` 是 C2 還是下載站？

狀態：**目前直接證據支持 download host；C2-like 需保守**

目前直接證據：

```text
URLhaus malware download URLs
Payload delivery table
HTTP GET /freda01.exe, /kidda.exe, OTX extra EXE paths
```

因此最精準寫法：

```text
malware download host / payload staging host
```

可寫 C2-like 或 infrastructure lead，但不要把它定為已證實 C2，除非有 beacon / callback / config evidence。

---

## 3. 目前未被本案資料證實 / 需要保留為待查的說法

### 3.1 `vrdccbank.com` 原屬印度 Virudhunagar Cooperative Bank 且已棄用 / 遭入侵

狀態：**待查**

使用者貼的 AI 摘要如此聲稱，但本工作區尚未完成獨立驗證：

```text
- vrdccbank.com 是否真為該銀行舊域
- 是否為 compromised website
- 是否為過期後重註冊/repurposed
- 官方 .bank.in 遷移公告是否存在
```

本案目前只確認：

```text
RDAP: vrdccbank.com registrar GoDaddy, active, registered 2023-03-11
crt.sh: vrdccbank.com / www / mail / webmail / autodiscover cert footprint
URLhaus: malware download
```

需要後續以官方網站、歷史快照、WHOIS history、RDAP history 驗證。

---

### 3.2 `88ee.dev/api/v1/collect`、OTP 即時攔截、Telegram Bot 回傳

狀態：**本案尚未證實**

本案已證實：

```text
npa-service.com -> 88ee.dev gambling landing
88ee.dev title: 88ee - Sân Chơi Giải Trí Cá Cược Số 1 Thị Trường
Cloudflare / Vietnamese gambling page
```

但尚未證實：

```text
/api/v1/collect endpoint
Telegram bot token / api.telegram.org requests
OTP interception panel
mobile-only phishing form
bank credential exfiltration
```

這些是常見 phishing kit pattern，但目前不能寫成本案事實。下一步需 urlscan detail / MHTML / JS extraction / page source / screenshots 佐證。

---

### 3.3 `npa-service.com` 註冊商 Namecheap / Alibaba Cloud

狀態：**與本案 RDAP 不符**

本案 RDAP 顯示：

```text
npa-service.com registrar: Dynadot Inc
NS: Cloudflare
Registration: 2025-09-11
```

因此 Namecheap / Alibaba Cloud 只能視為外部 AI 泛化說法，不適用於目前觀測。

---

## 4. 新增 hunting pivots

### 4.1 vrdccbank extra EXE paths from OTX

```text
https://vrdccbank.com/4325.exe
http://vrdccbank.com/4325.exe
https://vrdccbank.com/000111333.exe
http://vrdccbank.com/Freda4.exe
http://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/favour4.exe
https://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/Freda4.exe
https://vrdccbank.com/Favour1.exe
https://vrdccbank.com/2222.exe
```

下一步：

- 查 URLhaus public page / OTX / HA / MalwareBazaar 是否有 payload SHA。
- 不直接下載 live EXE。

### 4.2 PureLogs JS delivery pattern for SOC retrohunt

可用於 hunts：

```text
wscript.exe OR cscript.exe
-> powershell.exe
-> -EncodedCommand OR -enc
-> environment variable-based ScriptBlock create
```

Joe Sandbox examples show encoded PowerShell like：

```text
powershell.exe -w h -nOP -nOnI -EncodedCommand ...
```

### 4.3 vrdccbank network rule

Confirmed Suricata SID：

```text
84721509
GET /kidda.exe
Host: vrdccbank.com
classtype: trojan-activity
```

本案可擴展 strict-core rule to additional paths：

```text
/freda01.exe
/kidda.exe
/4325.exe
/000111333.exe
/Freda4.exe
/Doppee7.exe
/favour4.exe
/Favour1.exe
/2222.exe
```

---

## 5. 檔案庫更新

相關檔案：

```text
CASE_LIBRARY_V6/11_GEEK_OSINT_SWEEP/GEEK_OSINT_SWEEP_V6.md
CASE_LIBRARY_V6/11_GEEK_OSINT_SWEEP/OTX_URL_OBSERVATIONS_V6.csv
CASE_LIBRARY_V6/11_GEEK_OSINT_SWEEP/OTX_GENERAL_SUMMARY_V6.csv
```

建議新增/更新：

```text
EXTERNAL_AI_CLAIMS_TRIAGE_V6.md
```

本檔已整理哪些外部 AI 說法可採、需修正、待查。
