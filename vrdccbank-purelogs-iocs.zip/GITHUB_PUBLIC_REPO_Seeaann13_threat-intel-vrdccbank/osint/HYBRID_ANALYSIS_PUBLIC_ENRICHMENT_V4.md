# Hybrid Analysis Public Enrichment — V4

產出時間：2026-06-09 Asia/Taipei

來源：Hybrid Analysis 公開 sample page 查詢。未登入、未使用企業帳號、未提交新樣本、未下載樣本、未執行樣本。

## 結論摘要

Hybrid Analysis 公開頁面已能補強多個核心樣本：

1. `vrdccbank_exe.exe` / `freda01.exe` hash：HA verdict `malicious`，AV Detection `71%`，label `Kryptik.Generic`。
2. `vrdccbank_kidda.exe` hash：HA verdict `malicious`，AV Detection `71%`，label `MSIL.Benin.Generic`。
3. `hkakkkaa_installer.exe` hash：HA page 存在，verdict `suspicious`，Associated URL 指向 `github.com/hkakkkaa/gdsssdggsg/releases/download/fsdfsd/Installer.exe`。
4. `init.exe` / `gcm.exe` / `unc.exe`：HA 均有 sandbox report，verdict `malicious`，並標示 anti-VM / evasive risk。
5. `bytecode.txt`：HA verdict `malicious`，Threat Score `100/100`，有 sandbox report；這補強「文字 payload 本身惡意」而非單純附屬檔。
6. `icon.txt` / `license.txt`：HA 標為 malicious，但 Falcon Sandbox 顯示文字格式不支援 detonation；仍可作靜態/關聯佐證。
7. `kardiaflow_malware.zip` / `wallet_hunter.zip`：HA page 存在，verdict `suspicious`，低 AV detection，但對應 Trojan.Win64.Agent 類 label。
8. `banking_app_2.1.zip` 與 `trasher_rat.exe` 的 SHA256 查詢為 404 / not found，需其他來源或自行提交。

---

## 查詢結果表

| 本案檔案 | SHA256 | Hybrid Analysis 狀態 | Verdict / Score | AV Detection | Label / Notes |
|---|---|---|---|---|---|
| `phishing-hunter/vrdccbank_exe.exe` / `vrdccbank_live.exe` | `552d93ad7c138a43436b6b25d8fab1fae07df05db54e1dfead674add33cfe81c` | page exists | `malicious` | `71%` | `Kryptik.Generic`; no Falcon detonation report |
| `phishing-hunter/vrdccbank_kidda.exe` | `c96a683aad76996c568dbc1632d8bbc6f86324231ece63de5b067c96a2167f3c` | page exists | `malicious` | `71%` | `MSIL.Benin.Generic`; no Falcon detonation report |
| `phishing-hunter/hkakkkaa_installer.exe` | `cea53bc27825e8bf321e998b70058599bd4aab58fec744e7c2e822f66137a3a6` | page exists | `suspicious` | `3%` | `Trojan.Win64`; associated URL: `hxxps://github.com/hkakkkaa/gdsssdggsg/releases/download/fsdfsd/Installer.exe`; no Falcon detonation report |
| `phishing-hunter/init.exe` | `ac5885b78810a7bf987ff6674f6717059e227df9c969b9fb46d00b2c0de1ba74` | page exists | `malicious`, Threat Score `56/100` | `52%` | `Adware.Generic`; sandbox report exists; label `Trojan.Win64.Genus`; risk assessment: evasive / known anti-VM trick |
| `phishing-hunter/malware_analysis/gcm.exe` | `4c469dadda5529047b063dd2e91ec36c409b4cbe6cf3576ae7db02e79e4d51f7` | page exists | `malicious`, Threat Score `56/100` | `49%` | `Lazy.Generic`; sandbox report exists; label `Trojan.Win64.Genus`; risk assessment: evasive / known anti-VM trick |
| `phishing-hunter/unc_wallet.exe` / nested `unc.exe` | `30694a0101abfeea642cb9de7fb7eb66789eea74d8d7257b39822d7dab59445d` | page exists | `malicious`, Threat Score `55/100` | `51%` | `Trojan.Generic`; two sandbox reports; one Windows 11 malicious label `Trojan.Win64.Agent`; risk assessment: evasive / known anti-VM trick |
| `phishing-hunter/malware_analysis/bytecode.txt` | `35d19eba58c4db6e034e7965ac41a2b02a26f26ca9cfcfb5ec8cb1690ec86c5e` | page exists | `malicious`, Threat Score `100/100` | Marked clean by MetaDefender | Type `script/javascript`; Falcon Sandbox report exists; 46 MITRE mapped indicators |
| `phishing-hunter/lua_bytecode.bin` / `icon.txt` family | `772ce19206d35699b4d2693c59f8c0bd1a927f287f8bf98bd14d65f1ff248828` | page exists | `malicious` | `7%` | `Trojan/LUA.Agent`; Falcon Sandbox submissions errored because text format not supported; execution parent relation exists |
| `wallet_hunter.zip/license.txt` | `357cd0a1601d24bbb7949637b352b0ace1f30f51f788a03cafa98316068938e0` | page exists | `malicious` | `11%` | `Trojan.Script`; text format not supported for detonation; multiple execution parents |
| `phishing-hunter/kardiaflow_malware.zip` | `fcb05c8c0a327dfc35730c213533f84e1cb8e0d58023a9a0b7d9e2aa3dbb847d` | page exists | `suspicious` | `3%` | `Trojan.Win64.Agent.oa`; no Falcon detonation report |
| `phishing-hunter/wallet_hunter.zip` | `de4372e86d6b7e3c9b31c2589a4f2dcc225517b8d3503c00d77fce311d17bf7d` | page exists | `suspicious` | `3%` | `Trojan.Win64.Agent`; no Falcon detonation report |
| `phishing-hunter/banking-app/forel/banking_app_2.1.zip` | `866c2c331b181e8548de150f275d43de769acb31578099ae36622e28e67b10df` | 404 | not found | n/a | Need other source / optional user-side submission |
| `phishing-hunter/trasher_rat.exe` | `c8da19baa3ef207f5b249e603387f7b8f8ae5b6da1dff406f98e59610d6d0179` | 404 | not found | n/a | Our local static triage says not MZ, starts with HTML doctype |

---

## 關聯解讀

### 1. vrdccbank line

HA 對 `552d93...` 與 `c96a68...` 都給出 `malicious` 與 71% AV detection。這直接補強：

```text
vrdccbank.com/freda01.exe -> 552d93...
vrdccbank.com/kidda.exe   -> c96a68...
```

可更新 registrar / URLhaus / CERT 通報，加入 Hybrid Analysis 公開 verdict。

### 2. LuaJIT / SmartLoader-like line

`init.exe`、`gcm.exe`、`unc.exe` 都有 Hybrid Analysis sandbox reports，且有 anti-VM / evasive risk。這與本案靜態 triage 中看到的：

```text
LuaJIT 2.1.0-beta3
IsDebuggerPresent
QueryPerformanceCounter
Sleep
VirtualAlloc / VirtualProtect
launcher -> exe + text payload
```

互相補強。

### 3. text payload line

`bytecode.txt` 本身在 HA 被判 `malicious` 且 Threat Score `100/100`，這點很重要：它不是單純 companion text，而是可被沙箱/平台判惡意的 script-like payload。

### 4. hkakkkaa line

`cea53...` 在 HA 有 associated URL：

```text
hxxps://github.com/hkakkkaa/gdsssdggsg/releases/download/fsdfsd/Installer.exe
```

這補強 GitHub 通報中的 `hkakkkaa/gdsssdggsg` release asset 關聯。

---

## 建議更新

1. `REPORT_GITHUB_ABUSE_V3.md`：加入 Hybrid Analysis associated URL evidence for `hkakkkaa_installer.exe`。
2. `REPORT_REGISTRAR_HOSTING_VRDCCBANK_V3.md`：加入 HA verdict for `freda01.exe` and `kidda.exe`。
3. `REPORT_URLHAUS_UPDATE_V3.txt`：加入 HA public verdict / labels。
4. `IOC_MALWARE_HASHES_ORIGINAL_V3.csv`：新增欄位 `hybrid_analysis_verdict` / `hybrid_analysis_label`。
5. `FINAL_CASE_REPORT_V4_ZH.md`：新增 Hybrid Analysis enrichment section。

## 注意

未登入狀態下無法取得完整 Falcon Sandbox IOC/behavior details，也沒有提交新樣本。若需要完整 behavior/PCAP/API logs，需使用有權限帳號、API key、或由使用者手動提交並提供報告連結/匯出檔。
