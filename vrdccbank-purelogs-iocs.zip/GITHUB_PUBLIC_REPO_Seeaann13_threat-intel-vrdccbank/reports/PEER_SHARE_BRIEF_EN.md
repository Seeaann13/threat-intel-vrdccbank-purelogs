# Peer-share brief V6 — vrdccbank / GitHub SmartLoader leads

> Research / sharing handle: `Seeaann13`


TLP suggestion: **TLP:AMBER** for trusted researchers, or **TLP:CLEAR** only after removing GitHub account commentary and keeping pure IOCs.

This is a defensive intelligence note. GitHub account names are treated as **technical account/repository/release leads only**. No real-world identity or intent is asserted.

## 1. vrdccbank.com: PureLogsStealer delivery and possible rotating EXE paths

Confirmed anchors:

- `https://vrdccbank.com/freda01.exe`
  - URLhaus ID: `3859115`
  - Payload SHA256: `552d93ad7c138a43436b6b25d8fab1fae07df05db54e1dfead674add33cfe81c`
  - Signature: `PureLogsStealer`
  - Hybrid Analysis: malicious, AV 71%, `Kryptik.Generic`
- `https://vrdccbank.com/kidda.exe`
  - URLhaus ID: `3858409`
  - Payload SHA256: `c96a683aad76996c568dbc1632d8bbc6f86324231ece63de5b067c96a2167f3c`
  - Signature: `PureLogsStealer`
  - Hybrid Analysis: malicious, AV 71%, `MSIL.Benin.Generic`
  - EveBox / Suricata rule: SID `84721509`, `GET /kidda.exe`, Host `vrdccbank.com`

Additional OTX-observed EXE paths on `103.174.10.44` that may be worth validating without direct payload download:

```text
https://vrdccbank.com/4325.exe
http://vrdccbank.com/4325.exe
https://vrdccbank.com/000111333.exe
http://vrdccbank.com/Freda4.exe
http://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/favour4.exe
https://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/Freda4.exe
https://vrdccbank.com/Favour1.exe
https://vrdccbank.com/2222.exe
```

Interpretation: likely payload staging / malware download host with rotating EXE names. Direct C2 role is not confirmed from our evidence.

## 2. GitHub release/raw asset leads

### hkakkkaa/gdsssdggsg

URLhaus public ID `3631593`:

```text
https://github.com/hkakkkaa/gdsssdggsg/releases/download/fsdfsd/Installer.exe
SHA256: cea53bc27825e8bf321e998b70058599bd4aab58fec744e7c2e822f66137a3a6
```

Hybrid Analysis page for the same hash shows associated URL pointing to that GitHub asset.

GitHub release metadata, tag `fsdfsd`, published `2025-09-13T02:26:51Z`, includes 12 assets. Notable download counts:

```text
lol.exe         85,934
lol11.exe       50,295
1210.exe        45,635
1488.exe        44,181
lol1.exe        44,265
Installer.exe   41,953
```

### Namanpaliyal/KardiaFlow

URLhaus ID `3836159`:

```text
https://github.com/Namanpaliyal/KardiaFlow/raw/refs/heads/main/app/static/Kardia-Flow-1.5.zip
Payload SHA256: fcb05c8c0a327dfc35730c213533f84e1cb8e0d58023a9a0b7d9e2aa3dbb847d
Tags: SmartLoader, zip
```

GitHub tree metadata shows:

```text
app/static/Kardia-Flow-1.5.zip size 547,027 blob e485861c1a3ddc60efe015b5a838a66d9163bb06
app/Flow-Kardia-1.8.zip size 1,394,468 blob 68d141d8ef8229b9d6c93b4cf4e6174a13d262fd
```

### momofrd00/jquery-status-message

URLhaus ID `3830669`:

```text
https://github.com/momofrd00/jquery-status-message/raw/refs/heads/main/css/status_message_jquery_2.2.zip
Payload SHA256: 00eb8ca8ec61f58f275fc56635354a043274fa1e0ada579c15942f0fa3018979
Tags: SmartLoader, zip
```

GitHub tree metadata shows:

```text
css/status_message_jquery_2.2.zip size 493,748 blob 42eb16324b17e41452d9e6ed64f90ec2f21c5935
```

## 3. npa-service.com / 88ee.dev redirect-gambling lead

Evidence summary:

- `npa-service.com` RDAP: Dynadot, Cloudflare NS, registered `2025-09-11`.
- `88ee.dev` RDAP: Dynadot, Cloudflare NS, registered `2025-09-06`.
- urlscan/search and local crawl show final page title: `88ee - Sân Chơi Giải Trí Cá Cược Số 1 Thị Trường`.

Interpretation: likely brand-abuse/TDS/affiliate redirect destination. Not confirmed as malware core.

## 4. What we are not sharing

- No raw malware samples.
- No sensitive wallet/account MHTML.
- No personal attribution.
- No claims that a real person behind a GitHub profile is the attacker.
