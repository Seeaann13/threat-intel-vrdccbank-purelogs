# 同行分享簡報 V6 — vrdccbank / GitHub SmartLoader 線索

> 研究 / 分享識別名：`Seeaann13`


建議 TLP：可信小圈 `TLP:AMBER`；若公開，只保留純 IOC 並刪除帳號敘述。

本簡報只描述防禦情資。GitHub 帳號、repo、release 都是**技術線索**，不做人身歸因。

## 1. vrdccbank.com：PureLogsStealer 投遞與疑似輪替 EXE path

確認錨點：

- `https://vrdccbank.com/freda01.exe`
  - URLhaus ID: `3859115`
  - Payload SHA256: `552d93ad7c138a43436b6b25d8fab1fae07df05db54e1dfead674add33cfe81c`
  - Signature: `PureLogsStealer`
  - Hybrid Analysis: malicious, AV 71%, `Kryptik.Generic`
- `https://vrdccbank.com/kidda.exe`
  - URLhaus ID: `3858409`
  - Payload SHA256: `c96a683aad76996c568dbc1632d8bbc6f86324231ece63de5b067c96a2167f3c`
  - Signature: `PureLogsStealer`
  - Hybrid Analysis: malicious, AV 71%, `MSIL.Benin.Generic`
  - EveBox / Suricata SID: `84721509`，偵測 `GET /kidda.exe` + Host `vrdccbank.com`

OTX 額外觀測到的 EXE path（建議同行協助查 payload hash，不建議直接下載）：

```text
https://vrdccbank.com/4325.exe
http://vrdccbank.com/4325.exe
https://vrdccbank.com/000111333.exe
http://vrdccbank.com/Freda4.exe
http://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/favour4.exe
https://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/Freda4.exe
https://vrdccbank.com/Favour1.exe
https://vrdccbank.com/2222.exe
```

解讀：較像 payload staging / malware download host。C2 角色目前未由本案直接證實。

## 2. GitHub release/raw asset 線索

### hkakkkaa/gdsssdggsg

URLhaus public ID `3631593`：

```text
https://github.com/hkakkkaa/gdsssdggsg/releases/download/fsdfsd/Installer.exe
SHA256: cea53bc27825e8bf321e998b70058599bd4aab58fec744e7c2e822f66137a3a6
```

Hybrid Analysis 同 hash 顯示 associated URL 指向該 GitHub asset。

GitHub release metadata：

```text
Release tag: fsdfsd
Published: 2025-09-13T02:26:51Z
Assets: 12
```

高下載數 asset：

```text
lol.exe         85,934
lol11.exe       50,295
1210.exe        45,635
1488.exe        44,181
lol1.exe        44,265
Installer.exe   41,953
```

### Namanpaliyal/KardiaFlow

URLhaus ID `3836159`：

```text
https://github.com/Namanpaliyal/KardiaFlow/raw/refs/heads/main/app/static/Kardia-Flow-1.5.zip
Payload SHA256: fcb05c8c0a327dfc35730c213533f84e1cb8e0d58023a9a0b7d9e2aa3dbb847d
Tags: SmartLoader, zip
```

Git tree metadata：

```text
app/static/Kardia-Flow-1.5.zip size 547,027 blob e485861c1a3ddc60efe015b5a838a66d9163bb06
app/Flow-Kardia-1.8.zip size 1,394,468 blob 68d141d8ef8229b9d6c93b4cf4e6174a13d262fd
```

### momofrd00/jquery-status-message

URLhaus ID `3830669`：

```text
https://github.com/momofrd00/jquery-status-message/raw/refs/heads/main/css/status_message_jquery_2.2.zip
Payload SHA256: 00eb8ca8ec61f58f275fc56635354a043274fa1e0ada579c15942f0fa3018979
Tags: SmartLoader, zip
```

Git tree metadata：

```text
css/status_message_jquery_2.2.zip size 493,748 blob 42eb16324b17e41452d9e6ed64f90ec2f21c5935
```

## 3. npa-service.com / 88ee.dev 博弈導流線

證據摘要：

- `npa-service.com`：Dynadot、Cloudflare NS、註冊 2025-09-11。
- `88ee.dev`：Dynadot、Cloudflare NS、註冊 2025-09-06。
- urlscan / local crawl 顯示頁面標題：`88ee - Sân Chơi Giải Trí Cá Cược Số 1 Thị Trường`。

解讀：疑似 brand-abuse / TDS / affiliate redirect destination。不是目前 malware 核心。

## 4. 不分享項目

- 不分享 raw malware。
- 不分享錢包 / 帳號 MHTML。
- 不分享敏感截圖。
- 不做人身歸因。
- 不宣稱 GitHub profile 背後自然人就是攻擊者。
