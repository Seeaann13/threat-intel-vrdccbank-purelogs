# vrdccbank / PureLogs / GitHub SmartLoader-adjacent IOC Notes

Research handle: **Seeaann13**  
TLP: **CLEAR for the sanitized IOC/report content in this repository**.  
No raw malware samples are included.

## Summary

This repository contains a sanitized defensive threat-intelligence package for a cluster involving:

- `vrdccbank.com` PureLogsStealer malware download URLs
- GitHub release/raw asset malware distribution leads
- LuaJIT / SmartLoader-like loader artifacts
- `npa-service.com -> 88ee.dev` gambling/redirect lead

This repository does **not** assert real-world identity or intent behind any GitHub account. Account names and repositories are treated as technical platform leads only.

## Key confirmed anchors

### vrdccbank.com

| URL | Evidence | Payload SHA256 | Notes |
|---|---|---|---|
| `https://vrdccbank.com/freda01.exe` | URLhaus `3859115` | `552d93ad7c138a43436b6b25d8fab1fae07df05db54e1dfead674add33cfe81c` | PureLogsStealer; Hybrid Analysis malicious |
| `https://vrdccbank.com/kidda.exe` | URLhaus `3858409` | `c96a683aad76996c568dbc1632d8bbc6f86324231ece63de5b067c96a2167f3c` | PureLogsStealer; Hybrid Analysis malicious; Suricata SID `84721509` |

Additional OTX-observed paths needing validation:

```text
https://vrdccbank.com/4325.exe
http://vrdccbank.com/4325.exe
https://vrdccbank.com/000111333.exe
http://vrdccbank.com/Freda4.exe
http://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/favour4.exe
https://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/Freda4.exe
https://vrdccbank.com/Favour1.exe
https://vrdccbank.com/2222.exe
```

### GitHub technical platform leads

- `hkakkkaa/gdsssdggsg` release `fsdfsd`: multiple URLhaus-listed EXE assets; `Installer.exe` SHA256 `cea53bc27825e8bf321e998b70058599bd4aab58fec744e7c2e822f66137a3a6`.
- `Namanpaliyal/KardiaFlow`: URLhaus-listed `Kardia-Flow-1.5.zip`, payload SHA256 `fcb05c8c0a327dfc35730c213533f84e1cb8e0d58023a9a0b7d9e2aa3dbb847d`.
- `momofrd00/jquery-status-message`: URLhaus-listed `status_message_jquery_2.2.zip`, payload SHA256 `00eb8ca8ec61f58f275fc56635354a043274fa1e0ada579c15942f0fa3018979`.

## Repository contents

```text
iocs/       CSV indicators and hash lists
reports/    Sanitized analysis briefs
rules/      Draft YARA / Suricata-style rules
osint/      Public-source enrichment summaries
templates/  Copy-paste submissions for OTX/MISP/peer sharing
```

## Important caution

Do not use this repository to harass or accuse natural persons. GitHub account names are platform identifiers and should be treated as technical leads pending platform-side evidence.

## Contact

Shared by: **Seeaann13**
