rule Defensive_Loader_And_VRDCCBank_IOCs_V3 {
  meta:
    description = "Defensive strings for vrdccbank and LuaJIT/SmartLoader-like artifacts"
    author = "Arena defensive sandbox lab"
  strings:
    $s0 = "Kardia-Flow-1.5.zip" ascii nocase
    $s1 = "LuaJIT" ascii nocase
    $s2 = "Software_1.9.zip" ascii nocase
    $s3 = "bytecode.txt" ascii nocase
    $s4 = "freda.exe" ascii nocase
    $s5 = "freda01.exe" ascii nocase
    $s6 = "gcm.exe" ascii nocase
    $s7 = "github_io_namanpaliyal_v2.0.zip" ascii nocase
    $s8 = "kidda.exe" ascii nocase
    $s9 = "luajit" ascii nocase
    $s10 = "start gcm.exe bytecode.txt" ascii nocase
    $s11 = "start init.exe icon.txt" ascii nocase
    $s12 = "start unc.exe license.txt" ascii nocase
    $s13 = "vrdccbank" ascii nocase
  condition:
    2 of them
}
