# OTX Pulse Template

Title:

```text
vrdccbank PureLogsStealer delivery + GitHub SmartLoader-adjacent leads — Seeaann13
```

Description:

```text
Sanitized defensive IOC delta shared by Seeaann13.
This pulse tracks vrdccbank.com PureLogsStealer malware delivery and GitHub release/raw asset leads observed in URLhaus / Hybrid Analysis / OTX / GitHub public metadata.
No raw malware samples. No real-world attribution. GitHub accounts are technical platform leads only.
```

Tags:

```text
PureLogsStealer, malware-download, URLhaus, SmartLoader, GitHub, vrdccbank, infostealer, Seeaann13
```

Indicators to add:

```text
vrdccbank.com
https://vrdccbank.com/freda01.exe
https://vrdccbank.com/kidda.exe
https://vrdccbank.com/4325.exe
https://vrdccbank.com/000111333.exe
http://vrdccbank.com/Freda4.exe
http://vrdccbank.com/Doppee7.exe
https://vrdccbank.com/favour4.exe
https://vrdccbank.com/Favour1.exe
https://vrdccbank.com/2222.exe
552d93ad7c138a43436b6b25d8fab1fae07df05db54e1dfead674add33cfe81c
c96a683aad76996c568dbc1632d8bbc6f86324231ece63de5b067c96a2167f3c
cea53bc27825e8bf321e998b70058599bd4aab58fec744e7c2e822f66137a3a6
ac5885b78810a7bf987ff6674f6717059e227df9c969b9fb46d00b2c0de1ba74
4c469dadda5529047b063dd2e91ec36c409b4cbe6cf3576ae7db02e79e4d51f7
30694a0101abfeea642cb9de7fb7eb66789eea74d8d7257b39822d7dab59445d
35d19eba58c4db6e034e7965ac41a2b02a26f26ca9cfcfb5ec8cb1690ec86c5e
772ce19206d35699b4d2693c59f8c0bd1a927f287f8bf98bd14d65f1ff248828
357cd0a1601d24bbb7949637b352b0ace1f30f51f788a03cafa98316068938e0
```

References:

```text
https://urlhaus.abuse.ch/url/3859115/
https://urlhaus.abuse.ch/url/3858409/
https://urlhaus.abuse.ch/url/3631593/
https://rules.evebox.org/pub/abuse.ch/urlhaus/84721509
https://hybrid-analysis.com/sample/552d93ad7c138a43436b6b25d8fab1fae07df05db54e1dfead674add33cfe81c
https://hybrid-analysis.com/sample/c96a683aad76996c568dbc1632d8bbc6f86324231ece63de5b067c96a2167f3c
https://hybrid-analysis.com/sample/cea53bc27825e8bf321e998b70058599bd4aab58fec744e7c2e822f66137a3a6
```
