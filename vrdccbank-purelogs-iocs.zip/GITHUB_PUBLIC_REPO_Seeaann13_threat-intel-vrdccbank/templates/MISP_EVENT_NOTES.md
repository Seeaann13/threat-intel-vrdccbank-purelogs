# MISP Event Notes

Event title:

```text
Seeaann13 - vrdccbank PureLogsStealer delivery and GitHub SmartLoader-adjacent leads
```

Distribution suggestion:

```text
Your organization / connected communities first; review before wider distribution.
```

Threat level:

```text
High for vrdccbank malware download URLs.
Medium/High for GitHub release/raw asset leads pending platform review.
```

Analysis:

```text
Ongoing
```

Tags:

```text
tlp:amber
malware="PureLogsStealer"
threat-actor="unknown"
type="osint"
source="Seeaann13"
```

Attach/import:

```text
iocs/IOC_DELTA_V6.csv
iocs/IOC_CONFIRMED_AND_PRIORITY.csv
iocs/IOC_MALWARE_HASHES.csv
```
